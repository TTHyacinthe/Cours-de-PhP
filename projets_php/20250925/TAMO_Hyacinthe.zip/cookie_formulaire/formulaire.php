<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Choisir une couleur</title>
</head>
<body>
    <h2>Choisis ta couleur préférée</h2>
    <form action="index" method="post">
        <select name="couleur">
            <option value="red">Rouge</option>
            <option value="blue">Bleu</option>
            <option value="green">Vert</option>
            <option value="yellow">Jaune</option>
            <option value="orange">Orange</option>
            <option value="purple">Violet</option>
            <option value="pink">Rose</option>
            <option value="brown">Marron</option>
            <option value="black">Noir</option>
            <option value="gray">Gris</option>
        </select>
        <button type="submit">Envoyer</button>
    </form>
</body>
</html>
